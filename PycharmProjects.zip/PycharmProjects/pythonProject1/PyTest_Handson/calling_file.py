from PyTest_Handson.inspect_stack import Hi


class Calling():

    def calling_function(self):
        hi = Hi()
        print(hi.raiseNotDefined())

janani = Calling()
janani.calling_function()


