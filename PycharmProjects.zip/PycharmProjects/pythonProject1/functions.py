# function declaration
def wishes(name):
    print("happy birthday", name)


wishes("janani")


def maths(a, b):
    return (a - b)


print(maths (10, 4))

