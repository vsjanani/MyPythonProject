a = 100
if a:
    print("a is not equal to zero")
    print("check loop closing")
else:
    print("a is equal to zero")
    print("checking second line")

print("if else understood")

add = 0
for i in range(1, 6):
    add = add + i
print (add)

i = 4
while i>1:
    if i==3 :
        i = i - 1
        continue
    print(i)
    i =  i-1
print ("while loop understood")


