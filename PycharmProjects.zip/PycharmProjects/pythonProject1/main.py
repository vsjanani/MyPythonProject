print("sarvam krishnarpanam")
b, c = "janani", 8
print("my name is %s and my age is %d" % (b,  c))
print("my name is", b)
print("{},{}".format(b,c))
string = "hello world"
print("string to print is %s" % string)
mylist = [1,2,3, "h", 8, 2.5]
print(mylist)
print("last value of mylist is", mylist[-1])
mylist[1] = 20
print(mylist)
mylist.insert(2,30)
print(mylist)
del mylist[2]
print(mylist)
mylist.remove(3)
print(mylist)
mydict = {"hi" : 1, 22 :
    "hello janani" }
print(mydict.keys())
str = "jananidinesh"
print(str.strip("jan"))

string = 'android is awesome'
print(string.strip('an'))
mylist.append(100)
print(mylist)
