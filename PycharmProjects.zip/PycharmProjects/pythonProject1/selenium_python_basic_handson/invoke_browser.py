import selenium.webdriver.remote.webdriver
from selenium import webdriver
# from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

serviceobj = Service("/usr/bin/chromedriver")
webdriverobj = webdriver.Chrome(service=serviceobj)

webdriverobj.get("https://www.amazon.in")
webdriverobj.maximize_window()
print(webdriverobj.title)
print(webdriverobj.current_url)
# print(webdriverobj.refresh(), "refreshed")
webdriverobj.find_element(By.ID, "nav-a nav-a-2   nav-progressive-attribute").cli