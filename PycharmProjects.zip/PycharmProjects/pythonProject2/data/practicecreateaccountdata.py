class CreateAccountData:
    createAccountData = [{"Your name": "janani", "Mobile number": 123456, "Email": "123@123.com", "Password": 123456}]
