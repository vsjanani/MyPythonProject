import pytest


# @pytest.mark.smoke
class TestHello:
    def test_add(self):
        print("goodnight")

    def test_sub(self):
        print("good morning")